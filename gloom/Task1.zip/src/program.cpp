// Local headers
#include "program.hpp"
#include "gloom/gloom.hpp"
#include "gloom/shader.hpp"

GLuint createTrianglesVAO(GLfloat vertices[], int verticesLength, GLuint indices[], int indicesLength)
{
	GLuint vao;
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	GLuint vbo;
	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, verticesLength * sizeof(GLfloat), vertices, GL_STATIC_DRAW);

	GLuint ebo;
	glGenBuffers(1, &ebo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indicesLength * sizeof(GLuint), indices, GL_STATIC_DRAW);

	return vao;
}

void runProgram(GLFWwindow* window)
{
	// Enable depth (Z) buffer (accept "closest" fragment)
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	// Configure miscellaneous OpenGL settings
	glEnable(GL_CULL_FACE);

	// Set default colour after clearing the colour buffer
	glClearColor(0.39f, 0.58f, 0.92f, 1.0f);

	// Set up your scene here (create Vertex Array Objects, etc.)

	// Create and fill vertex buffer for six triangles
	const int numberOfTriangles = 6;

	GLfloat vertices[numberOfTriangles * 3 * 2];
	GLuint indices[numberOfTriangles * 3];

	for (int i = 0; i < numberOfTriangles; i++) {
		float ox = ((i % 3) - 1) * 0.5f;
		float oy = (i / 3) - 0.5f;

		vertices[2 * (3 * i + 0) + 0] = ox;
		vertices[2 * (3 * i + 0) + 1] = oy + 0.2;
		indices[3 * i + 0] = 3 * i + 0;

		vertices[2 * (3 * i + 1) + 0] = ox - 0.2;
		vertices[2 * (3 * i + 1) + 1] = oy - 0.1;
		indices[3 * i + 1] = 3 * i + 1;

		vertices[2 * (3 * i + 2) + 0] = ox + 0.2;
		vertices[2 * (3 * i + 2) + 1] = oy - 0.1;
		indices[3 * i + 2] = 3 * i + 2;
	}

	GLuint vao = createTrianglesVAO(vertices, numberOfTriangles * 2 * 3, indices, numberOfTriangles * 3);

	Gloom::Shader shader;
	shader.attach("../gloom/shaders/simple.frag");
	shader.attach("../gloom/shaders/simple.vert");
	shader.link();

	shader.activate();

	// Specify the layout of the vertex data
	GLint positionAttribute = glGetAttribLocation(shader.get(), "position");
	glEnableVertexAttribArray(positionAttribute);
	glVertexAttribPointer(positionAttribute, 2, GL_FLOAT, GL_FALSE, 0, 0);

	// Rendering Loop
	while (!glfwWindowShouldClose(window))
	{
		fprintf(stderr, "1");
		printGLError();

		// Clear colour and depth buffers
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Draw triangles
		glDrawElements(GL_TRIANGLES, numberOfTriangles * 3, GL_UNSIGNED_INT, 0);

		// Handle other events
		glfwPollEvents();
		handleKeyboardInput(window);

		// Flip buffers
		glfwSwapBuffers(window);
	}
}


void handleKeyboardInput(GLFWwindow* window)
{
	// Use escape key for terminating the GLFW window
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}
}
